package ServidorAgenda;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import ClienteAgenda.Agenda;

public class Servidor extends Thread {

	protected Socket socket;

	public Servidor(Socket socket) {
		this.socket = socket;
	}

	public static void main(String[] args) {

		List<Agenda> lista = new ArrayList<Agenda>();
		Agenda agenda = new Agenda();
		int telefono;
		String nombre;
		
		try {
			ServerSocket ss = new ServerSocket();
			Socket socket;
			InetSocketAddress inet = new InetSocketAddress("localhost", 5555);
			ss.bind(inet);
			System.out.println("Serividor en marcha");

			
			while (true) {
				socket = ss.accept();
				Servidor prueba = new Servidor(socket);
				prueba.start();
				
				DataInputStream entrada = new DataInputStream(socket.getInputStream());
				DataOutputStream salida = new DataOutputStream(socket.getOutputStream());
				
				int id = entrada.readInt();

				if (id == 1) {
					nombre = entrada.readUTF();
					telefono = entrada.readInt();
					
					agenda.setNombre(nombre);
					agenda.setTelefono(telefono);
					lista.add(agenda);
					agenda = new Agenda();	
				}
				
				else if (id == 2) {
					salida.writeUTF(lista.toString());
				}
				
				else if (id == 3) {
					int telefonomod = entrada.readInt();
					String nuevonombre = entrada.readUTF();
					int nuevotelefono = entrada.readInt();
					for (int i=0 ; i<lista.size() ; i++) {
						if(telefonomod == lista.get(i).getTelefono()){
							lista.get(i).setTelefono(nuevotelefono);
							lista.get(i).setNombre(nuevonombre);
						}
					}
					salida.writeUTF(lista.toString());
				}
				
				else if (id == 4) {
					System.out.println("Hasta luego");
					ss.close();
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
