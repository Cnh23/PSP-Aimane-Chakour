package ClienteAgenda;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
	public static void main(String[] args) {
		Socket socket = new Socket();
		Scanner sc = new Scanner(System.in);
		InetSocketAddress inet = new InetSocketAddress("localhost", 5555);
		int id = 0;
		int telefono;
		String nombre;
		String resultado;
		
		try {
			socket.connect(inet);
			DataInputStream entrada = new DataInputStream(socket.getInputStream());
			DataOutputStream salida = new DataOutputStream(socket.getOutputStream());
			
			System.out.println("1 crear contacto");
			System.out.println("2 ver contactos");
			System.out.println("3 modificar contacto");
			System.out.println("4 salir");
			
			id = sc.nextInt();
			salida.writeInt(id);
			
			if (id == 1) {
				System.out.println("Nombre a introducir: ");
				nombre = sc.next();
				salida.writeUTF(nombre);
				
				System.out.println("telefono a introducir: ");
				telefono = sc.nextInt();
				salida.writeInt(telefono);
				
				System.out.println("El contacto " + nombre + " con tel�fono " + telefono + " se ha a�adido correctamente");
				
				
			}
			else if (id == 2) {
				resultado = entrada.readUTF();
				System.out.println("resultado: " + resultado);
			}
			else if (id == 3) {
				System.out.println("Introduzca telefono a modificar");
				telefono = sc.nextInt();
				salida.writeInt(telefono);
				
				System.out.println("Introduzca nuevo nombre");
				String nuevonombre = sc.next();
				salida.writeUTF(nuevonombre);
				
				System.out.println("Introduzca nuevo telefono");
				int nuevonumero = sc.nextInt();
				salida.writeInt(nuevonumero);
				
				System.out.println("El contacto ha sido modificado");
				
				resultado = entrada.readUTF();
				System.out.println("resultado: " + resultado);
			}
			else if (id==4) {
				System.out.println("Hasta luego");
				socket.close();
				sc.close();
			}
		} catch (IOException e) {
// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
